/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mainapplication.models;

/**
 *
 * @author João Miguel
 */
public class DroideBatalhaB2 extends DarkSide{
    public DroideBatalhaB2(String name, int age, double weight) {
        super(name, age, weight , 10 , "Droide de Batalha B2");
    }
    
    public DroideBatalhaB2(Guerreiro guerreiro) {
        super(guerreiro);
    }

    @Override
    public void attack(Arena arena) {// Função N° 13
        super.attack(arena);
        hit(0 , arena);
    }   

    @Override
    public void alterHp(int alter , Arena arena) {// Função N° 11
        Guerreiro newb2 = null;
        super.alterHp(alter , arena); 
        if (this.getHp() == 0 && this.getHp_ref() > 1) {
            System.out.println("\n\n->> [HABILIDADE] O Droide B2 se morreu e renaceu em dois novos Droides B2 cada um com " +  (this.getHp_ref()/2));
            for (int i = 1; i <= 2; i++) {
                newb2 = new DroideBatalhaB2(this);
                newb2.setHp(this.getHp_ref()/2);
                newb2.setHp_ref(this.getHp_ref()/2);
                newb2.setName(this.getName()+"."+i);
                arena.getCurrentLineTeam2().add(newb2);
                newb2 = null;
            }
        }
    }
}

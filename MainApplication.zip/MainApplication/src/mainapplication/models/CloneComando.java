/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mainapplication.models;

import java.util.ArrayList;

/**
 *
 * @author João Miguel
 */
public class CloneComando extends LightSide{
    
    public CloneComando(String name, int age, double weight) {
        super(name, age, weight , 40, "Clone Comando");
    }

    @Override
    public void attack(Arena arena) {// Função N° 13
        super.attack(arena);
        int equals = 0;
        ArrayList<Guerreiro> jc = arena.getCurrentLineTeam1();
        if (jc.size() > 1)
        {
            for (int i = 1; i < jc.size(); i++) 
                if(jc.get(i).getClass() == this.getClass())
                    equals++;
            if (equals > 0)System.out.println("\n\n->> [HABILIDADE] O Clone Comando atual encontro "+equals+" semelhantes seus na fila para ajuda no ataque e vai dar "+(equals*8)+" a mais de dano neste ataque");
        }
        setHit(getHit()-(equals*8));
        hit(0 , arena);
        setHit(getHit()+(equals*8));
    }

}
